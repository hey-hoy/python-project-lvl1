"""Run is it prime game."""
from brain_games.game_engine import run
from brain_games.games import prime as game


def main():
    """Run is it prime game."""
    run(game)


if __name__ == '__main__':
    main()
