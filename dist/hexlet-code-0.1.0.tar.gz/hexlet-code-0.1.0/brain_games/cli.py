def welcome_user():
    import prompt

    return prompt.string('May I have your name? ')